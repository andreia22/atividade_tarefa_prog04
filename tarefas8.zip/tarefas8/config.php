<?php


// conexão ao banco de dados (MySql)


define("BD_SERVIDOR", "127.0.0.1");
define("BD_USUARIO", "root");
define("BD_SENHA", "root");
define("BD_BANCO", "tarefa");

define("EMAIL_NOTIFICACAO", "andreiaunoesc2023@gmail.com");
