<html>
<head>
	<title> dia <?php echo date('d/m/y'); ?></title>
</head>

<body>
	<h1> Estamos em <?php echo date('y');?> e  hoje é dia <?php echo date ('d/m');?>

<p> Está pagina foi gerada às <?php echo date ('H');?>  horas e <?php echo date('i');?> minutos
</p>

<?php
 function linha($semana){
 	$linha = '<tr>';

 	for ($i = 0; $i <= 6; $i++){
 		if(array_key_exists($i, $semana)){
 			$linha .= "<td>{$semana[$i]}</td>";
 		}else {
 			$linha .= "<td></td>";
 		}

 	}

 	$linha .= '</tr>';

 	return $linha;
 }

function calendario(){
	$calendario = '';
	$dia =  1;
	$semana = [];

	while ($dia <= 31) {
		 array_push($semana, $dia);

		if (count($semana) == 7) {
			$calendario .= linha($semana);
			$semana = [];
		}

		$dia++;
	}


// Hack do calemdario
	$calendario .= linha($semana);
	return $calendario;
}

/*

array PHP

$dias = array();
$meses = [];


$dias = array('Segunda', 'Terça', 'Quarta', '...');
$meses = ['janeiro', 'Fevereiro', 'Março', '...'];

echo $meses[1];  // Fevereiro

*/

?>
</h1>
<table border="1"> 
	<tr>
		<th>Dom</th>
		<th>Seg</th>
		<th>Ter</th>
		<th>Qua</th>
		<th>Qui</th>
		<th>Sex</th>
		<th>Sab</th>
		
	</tr>
	<?php echo calendario();?>
	

</table>
</body>

</html>